auth.onAuthStateChanged(user => {
    if (user) {
      console.log('user logged in: ', user);
    } else {
      console.log('user logged out');
    }
  })
// signup
const signupForm = document.querySelector('#login');
signupForm.addEventListener('submit', (e) => {
 e.preventDefault();

  // get user info
       
  const email = document.getElementById('email').value;
  const password = document.getElementById('pass').value;
console.log(email,password)
 // sign up the user
  auth.signInWithEmailAndPassword(email, password).then(cred => {
    console.log(cred.user);
   
    swal({
        title: "Good job!",
        text: "Successfully Logged In",
        icon: "success",
        button: "ok",
    }).then((value) => {
        location.href = "./index.html"
    }).catch((error) => {
        var errorCode = error.code;
        var errorMessage = error.message;
        console.log("Error", errorMessage)
        swal("OOpS!", errorMessage, "error");

    })
   
    signupForm.reset();
  });
})