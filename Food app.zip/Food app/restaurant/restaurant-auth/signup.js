
// signup
const signupForm = document.querySelector('#signup-form');
signupForm.addEventListener('submit', (e) => {
 e.preventDefault();

  // get user info
  const resName = document.getElementById('resName').value;
    const country = document.getElementById('country').value;
    const city = document.getElementById('city').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('pass').value;
console.log(email,password)
 // sign up the user
  auth.createUserWithEmailAndPassword(email, password).then(cred => {
    console.log(cred.user);
    var restaurant = cred.user;
   
    db.collection("restaurant").doc(restaurant.uid).set({
        resName: resName,
        email: email,
        uid: restaurant.uid,
        password: password,
        country: country,

    })
    swal({
        title: "Good job!",
        text: "Successfully sign up",
        icon: "success",
        button: "ok",
    }).then((value) => {
        location.href = "./login.html"
    }).catch((error) => {
        var errorCode = error.code;
        var errorMessage = error.message;
        console.log("Error", errorMessage)
        swal("OOpS!", errorMessage, "error");

    })

    signupForm.reset();
  });
});