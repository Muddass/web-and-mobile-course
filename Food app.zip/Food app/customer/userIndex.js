db.collection("menu").doc("GcndIeGvTBQulFHejFze")
    .onSnapshot((doc) => {
        console.log("Current data: ", doc.data());
    });
