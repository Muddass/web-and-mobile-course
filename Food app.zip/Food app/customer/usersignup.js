
// signup
const signupForm = document.querySelector('#signup-form');
signupForm.addEventListener('submit', (e) => {
 e.preventDefault();

  // get user info
  const userName = document.getElementById('userName').value;
    const country = document.getElementById('country').value;
    const city = document.getElementById('city').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('pass').value;
console.log(email,password)
 // sign up the user
  auth.createUserWithEmailAndPassword(email, password).then(cred => {
   
    var customer = cred.user;
   
    db.collection("customer").doc(customer.uid).set({
        userName: userName,
        email: email,
        uid: customer.uid,
        password: password,
        country: country,

    })
    swal({
        title: "Good job!",
        text: "Successfully sign up",
        icon: "success",
        button: "ok",
    }).then((value) => {
        location.href = "./userLogin.html"
    }).catch((error) => {
        var errorMessage = error.message;
        swal("OOpS!", errorMessage, "error");

    })

    signupForm.reset();
  });
});